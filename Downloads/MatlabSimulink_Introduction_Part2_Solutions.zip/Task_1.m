% Control of Medical Instrumentation
% 2nd Matlab-Intro
% Summer semester 2020
clear all;
close all;
clc;

%% 1. Discrete-Time System
% a)
s = tf('s');
G1 = 4/(s^2 + 2*s + 4);
% check if BIBO stalbe
p = pole(G1);
if any(real(p) >= 0)
    disp('G1(s) is not BIBO stable')
else
    disp('G1(s) is BIBO stable')
end
% plot step response
figure();
step(G1, 5);
title('Task 3-a: Step response of G_1(s)');
legend('G1(s)');
xlabel('t');
ylabel('y(t)');
grid on;

%% b)
Td = 0.05; % sampling time
% discretize
G1d_impulse = c2d(G1, Td, 'impulse');
G1d_zoh = c2d(G1, Td, 'zoh');
% plot
figure();
hold on;
step(G1, 5);
step(G1d_impulse, 5);
step(G1d_zoh);
title('Task 3-b: Discretisation methods \newline\it{impulse} vs. \it{zoh}');
legend('continuous', 'impulse', 'zoh');
xlabel('t');
ylabel('y(t)');
grid on;
hold off;

%% c)
[num, den] = tfdata(G1, 'v');
simout = sim('Task_1c', 'StartTime', '0', 'StopTime', '5');
% stairs-plot
figure();
hold on;
step(G1, 5);
stairs(simout.t, simout.y, 'r')
title('Task 1-c: Simulink model: stairstep-graph');
legend('Matlab-Command', 'Simulink-Model');
xlabel('t');
ylabel('y(t)');
grid on;
hold off;
% stem-plot
figure();
hold on;
step(G1, 5);
stem(simout.t, simout.y, 'r')
title('Task 1-c: Simulink model: stem-graph');
legend('Matlab-Command', 'Simulink-Model');
xlabel('t');
ylabel('y(t)');
grid on;
hold off;

%% d)
figure();
hold on;
Td_array = [0.05, 0.2, 0.55];
for i = 1:length(Td_array)
   Td = Td_array(i);
   simout = sim('Task_1c', 'StartTime', '0', 'StopTime', '5');
   stairs(simout.t, simout.y)
end
title('Task 3-d: Sampling times - Stairstep-graph');
legend('Td = 0.05s', 'Td = 0.2s', 'Td = 0.55s');
xlabel('t');
ylabel('y(t)');
grid on;
hold off;
% stem-plot
figure();
hold on;
for i = 1:length(Td_array)
    Td = Td_array(i);
    simout = sim('Task_1c', 'StartTime', '0', 'StopTime', '5');
    subplot(3, 1, i);
    stem(simout.t, simout.y);
    title(sprintf('T_d = %.2fs', Td));
    grid on;
    xlabel('t');
    ylabel('y(t)');
end
hold off;
