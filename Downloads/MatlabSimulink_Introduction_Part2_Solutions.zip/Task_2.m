% Control of Medical Instrumentation
% 2nd Matlab-Intro
% Summer semester 2020
clear all;
close all;
clc;

%% 2. State controller
A = [0, -2;
     2, 7];
b = [1; -4];
cT = [1, 3];

x0 = [3; -2];
r = 30;

%% a)
lambda = [-2; -2];
kT = acker(A, b, lambda);

%% b)
simout = sim('Task_2b', 'StartTime', '0', 'StopTime', '10');
figure();
hold on;
plot(simout.t, simout.r, simout.t, simout.y);
title('Task 2-b: r(t) vs y(t)');
xlabel('t');
ylabel('r(t) / y(t)');
grid on;
hold off;

%% c) -> optional task
% create new system
Atilde = [A, zeros(2,1); 
          -cT, 0];
btilde = [b; 0];
% compute ktilde
lambda = [-2; -2; -2];
kTtilde = acker(Atilde, btilde, lambda);
% ki
ki_PI = kTtilde(3);
% kp
kp_PI = 1/(cT*inv(A)*b);
% kT
kT_PI = kTtilde(1:2) + kp_PI*cT;

% comparison of the state controller vs. the PI state controller
figure();
% plot state controller (simulation from task b)
simout = sim('Task_2b', 'StartTime', '0', 'StopTime', '10');
subplot(2,1,1)
plot(simout.t, simout.r, simout.t, simout.y);
hold on
title('State controller');
legend('r(t)', 'y(t)'); 
xlabel('t');
ylabel('r(t) / y(t)');
grid on;
hold off;
% plot PI state controller
%simout = sim('Task_2c', 'StartTime', '0', 'StopTime', '10');
% If you receive several Simulink errors with the Simulink file Task_2c
% (errors in the Matlab function of the PI state controller), use the
% simulation file 'Task_2c_2', which implements the PI state controller as 
% elementary blocks -> so remove the line above and uncomment the line below
simout = sim('Task_2c_2', 'StartTime', '0', 'StopTime', '10');
subplot(2,1,2)
plot(simout.t, simout.r, simout.t, simout.y);
hold on
title('PI state controller');
legend('r(t)', 'y(t)'); 
xlabel('t');
ylabel('r(t) / y(t)');
grid on;
hold off;

