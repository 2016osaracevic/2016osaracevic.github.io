% Control of Medical Instrumentation
% 2nd Matlab-Intro
% Summer semester 2020
clear all;
close all;
clc;

%% 3. Dealing with operating points
% a)
g = 9.81;
c = 0.00013632;
m = 0.06687;
L = 1.08;
R = 18;

%% b)
% operating points
ye = 0.013;
xe = [ye; 
      0;
      ye*sqrt(m*g/c)];
ue = R*ye*sqrt(m*g/c);
% linearized model
A = [0, 1 0;
     2*g/ye, 0, (-2/ye)*sqrt(c*g/m);
     0, 2/(L*ye)*sqrt(c*m*g), -R/L];
b = [0; 0; 1/L];
cT = [1, 0, 0];
d = 0;
sys = ss(A, b, cT, d);
% discretize
Td = 0.005;
sys_discrete = c2d(sys, Td);

%% c)
lambda = [0.8; 0.8; 0.8];
kT = acker(sys_discrete.A, sys_discrete.b, lambda);

%% d)
x0 = 3*xe;
r = 3*ye;
% plot
simout = sim('Task_3_complete', 'StartTime', '0', 'StopTime', '1');
figure();
hold on;
plot(simout.t, simout.y);
plot(simout.t, ones(size(simout.t)) * ye);  % draw a line a ye
title('Task 3: y(t)');
xlabel('t');
ylabel('y(t)');
legend('y(t)', 'ye = 0.013');
grid on;
hold off;
